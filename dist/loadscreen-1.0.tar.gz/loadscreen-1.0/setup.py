from setuptools import setup

setup(name='loadscreen',
      version='1.0',
      description='a simple library for creating a loading screen',
      packages=[],
      author='ErkinKraft',
      author_email='erkinkraft@gmail.com',
      zip_safe=False)